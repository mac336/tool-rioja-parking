# Handoff: Encuesta protagonista en el Home (Rioja 25)

## Overview
Rediseño de la visibilidad de la encuesta abierta en el Home de la app Rioja 25.
La fila discreta actual ("Votación slim" en `src/features/home/HomePage.tsx`) se
sustituye por una **tarjeta hero azul** colocada **arriba del todo del contenido,
por delante del "Tablón de la comunidad"**, con barra de participación, días
restantes y CTA "Votar ahora". Incluye un **estado urgente** (≤3 días) en tonos
ámbar. Cuando el vecino ya ha votado, la tarjeta **desaparece del Home**.

## About the Design Files
Los archivos de este paquete son **referencias de diseño creadas en HTML**
(Design Components, sintaxis `<x-dc>`/`{{ }}`): muestran el aspecto y el
comportamiento deseados, **no son código de producción**. La tarea es recrear
este diseño en el codebase existente (`tool-rioja-parking`: React + Vite +
Tailwind + lucide-react), siguiendo sus patrones. No ejecutes los `.dc.html`;
léelos como especificación visual (los valores están literales en los `style`).

## Fidelity
**Alta fidelidad (hifi).** Colores, tipografía, espaciados, radios y estados son
finales. El resto del Home no cambia; solo se toca la tarjeta de encuesta y su
posición.

## Cambio en el codebase (resumen para el dev)
En `src/features/home/HomePage.tsx`:
1. **Eliminar** el bloque actual "Votación slim" (el `<Link>` con punto azul +
   pill "Votar") que va después del parking strip.
2. **Añadir** la nueva tarjeta hero como **primer elemento** del contenido
   (antes de `<TablonBoard/>`). El tablón pasa a llevar `margin-top: 14px`.
3. Condición de render: solo si hay encuesta con `estado === 'abierta'` **y** el
   usuario aún no ha votado. Si ya votó → no se muestra nada (sin placeholder).
4. Necesita el dato de participación: nº de viviendas que han votado / total
   (ver State Management).

## Screens / Views

### Home · tarjeta "Encuesta protagonista" (estado normal)
- **Posición:** primer hijo del contenedor de contenido (`px-4`), antes del Tablón.
- **Contenedor:** `border-radius: 20px; padding: 16px; color: #fff;`
  `background: linear-gradient(160deg, #2F76C9, color-mix(in srgb, #1F5AA3 75%, #001217));`
  `box-shadow: 0 14px 30px -14px rgba(47,118,201,.5);`
  Es un `<Link to={'/votaciones/' + id}>` (toda la tarjeta pulsable).
- **Fila superior** (`flex; justify-content: space-between; gap: 8px`):
  - Overline izquierda: "ENCUESTA DE LA COMUNIDAD" — 11px / 700 / uppercase /
    `letter-spacing: 0.12em` / `rgba(255,255,255,.7)`.
  - Chip derecha: "Cierra en {N} días" — pill (`radius 999px`), alto 23px,
    `padding: 0 10px`, fondo `rgba(255,255,255,.16)`, texto #fff 11.5px / 700.
- **Título** (el título real de la encuesta, ej. "Encuesta de satisfacción"):
  `margin-top: 6px`, Bricolage Grotesque 19px / 800 / `letter-spacing:-0.015em`
  / `line-height: 1.2` / #fff.
- **Barra de participación:** `margin-top: 10px; height: 7px; border-radius: 999px;`
  track `rgba(255,255,255,.22)`; relleno #fff, `width: {votos/total*100}%`,
  mismo radius. (Transición suave del width, 200ms ease, opcional.)
- **Fila inferior** (`margin-top: 8px; flex; justify-content: space-between; gap: 10px`):
  - Texto: "{votos}/{total} viviendas han votado" — 12px `rgba(255,255,255,.85)`.
  - Botón "Votar ahora": pill blanca, alto 36px, `padding: 0 18px`, texto
    `#1F5AA3` 13px / 800, `flex-shrink: 0`. (Decorativo: el link es la tarjeta;
    o botón real con `stopPropagation`, a criterio del codebase.)

### Home · estado urgente (quedan ≤3 días)
Misma estructura; cambian los colores y el chip:
- Fondo: `linear-gradient(160deg, #C97E2F, color-mix(in srgb, #8A5A0F 80%, #170f00));`
  sombra `0 14px 30px -14px rgba(207,138,23,.45)`.
- Overline `rgba(255,255,255,.75)`; texto inferior `rgba(255,255,255,.9)`.
- Chip: fondo `rgba(255,255,255,.2)`, peso 800, con icono `Hourglass` (lucide,
  11px, stroke 2.2) + texto "Cierra mañana" / "Cierra hoy" / "Cierran N días"
  según reste (misma lógica de textos que el parking: hoy / mañana / N días).
- Botón: pill blanca, texto `#8A5A0F`.
- Umbral: `diasRestantes(cierre) <= 3`.

### Estado "ya votó"
La tarjeta no se renderiza. El Home queda como hoy (tablón primero).

## Interactions & Behavior
- Tap en la tarjeta (o en "Votar ahora") → navega a `/votaciones/{id}`.
- Sin animaciones de entrada; transiciones generales de la app (150–250ms ease).
- La tarjeta respeta `prefers-reduced-motion` (ya cubierto por global.css).
- Accesibilidad: la tarjeta es un único link con `aria-label` tipo
  "Encuesta de satisfacción, cierra en 22 días, votar ahora". Contraste AA:
  texto blanco sobre los degradados indicados cumple ≥4.5:1.

## State Management
- Ya existe: `encuestas = useAsync(listEncuestas, [])` y
  `abierta = encuestas.data?.find(e => e.estado === 'abierta')`.
- Nuevo: participación de la encuesta abierta → `{ votos: number, total: number }`
  (viviendas que han votado / viviendas censadas, ej. 12/40) y
  `yaVoto: boolean` para la vivienda del usuario. Si la API de encuestas no lo
  expone aún, añadirlo al endpoint de detalle o a `listEncuestas`.
- `pct = Math.round(votos / total * 100)`.
- `urgente = diasRestantes(abierta.cierre) <= 3`.

## Design Tokens
Del sistema existente (`src/styles/tokens.css`), sin tokens nuevos:
- Info: `--info: #2F76C9`, `--info-ink` (claro `#1F5AA3`).
- Warn/urgencia: derivados de `--warn: #CF8A17` y `--warn-ink: #8A5A0F`
  (los dos degradados de arriba están literales; si se prefiere, definirlos como
  `--grad-encuesta` / `--grad-encuesta-urgente` junto a `--grad-hero`).
- Radios: tarjeta 20px (`--r-lg` ≈ 22px del sistema también vale), pills `--r-pill`.
- Tipos: título en `--font-display` (Bricolage Grotesque), resto `--font-ui` (Figtree).
- El diseño está validado en **modo oscuro**; en modo claro los degradados y el
  texto blanco no cambian (son autosuficientes).

## Assets
Sin assets nuevos. Icono `Hourglass` de lucide-react (ya es dependencia).

## Files
- `Home Encuesta.dc.html` — canvas con la versión final (sección `2a`), las tres
  exploraciones (`1a`–`1c`) y los estados urgentes. La tarjeta a implementar es
  la de `2a` (idéntica a `1c`).
- `HomeHeader.dc.html`, `HomeTablon.dc.html`, `HomeParking.dc.html`,
  `HomeTail.dc.html`, `HomeTabBar.dc.html` — cromo del Home recreado solo como
  contexto visual; **no implementar**, ya existen en el codebase
  (`HomePage.tsx`, `TablonBoard.tsx`, `TabBar.tsx`).
