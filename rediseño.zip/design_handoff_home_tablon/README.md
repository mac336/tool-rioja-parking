# Handoff: Home con Tablón de post-its (diseño 2a)

## Overview
Rediseño de la Home móvil de **Rioja 25** (392px). Sustituye el look neumórfico actual por un
diseño plano y pulido cuya pieza central es un **"Tablón de la comunidad"**: los mensajes
(avisos / anuncios / incidencias) se muestran como notas de papel pinchadas con chincheta.
Cuando hay varios mensajes de un tipo, la nota se ve **apilada** y al pulsarla se abre un
**bloc de post-its**: se levanta la hoja superior (arrastre con perspectiva) para revelar la
siguiente. Los accesos a módulos pasan a ser **círculos discretos**.

## About the Design Files
`Home Propuestas.dc.html` es una **referencia de diseño en HTML** (prototipo), no código de
producción. La tarea es **recrear el diseño 2a en el codebase existente** (`tool-rioja-parking`:
React 18 + Vite + Tailwind + lucide-react), usando sus patrones actuales (tokens CSS,
`useApp`, `useAsync`, rutas react-router). No copies el HTML tal cual: léelo como especificación
visual (los valores exactos están literales en los `style`).

La referencia contiene varias propuestas; **implementa solo la opción `2a`** (la primera,
arriba del lienzo). Ignora 1a/1b/1c/1d.

## Fidelity
**Alta fidelidad (hifi).** Colores, tipografía, espaciados, radios, sombras y la interacción
del bloc son finales. Diseñado a 392px de ancho; el layout es fluido (max-width 720px como hoy).

---

## Cambios por archivo (mapa de implementación)

### 1. `src/styles/tokens.css` — ajustes de tema
El diseño abandona el neumorfismo. Mantén los tokens y añade/ajusta:
- Fondo de pantalla: `--bg: #F4F7F9` (claro, casi blanco azulado; ya no hay sombras neu).
- Tarjetas: fondo `#FFFFFF`, `border: 1px solid var(--border)` (#D2DBE4), sombra
  `0 12px 26px -14px rgba(30,50,60,.35)` solo en el tablón; el resto sin sombra o `--shadow-sm`.
- Deja de usar `--shadow-neu*` en Home (pueden quedar para otras pantallas hasta migrarlas).
- Nueva fuente manuscrita: `--font-hand: "Caveat", cursive;` (Google Fonts, pesos 600/700).
  Añádela al `<link>` de fuentes en `index.html`.

### 2. `src/features/home/HomePage.tsx` — reestructura
Orden del contenido (de arriba a abajo):
1. **Header claro compacto** (sustituye el header degradado):
   - Fondo `--bg`, sin degradado. Izquierda: logo badge 42×42, radio 14,
     `linear-gradient(160deg, var(--brand-from), var(--brand-to))`, tejado SVG + "25" en Bricolage 12/800.
   - Al lado: "Buenos días, Marta" (Bricolage 19/800, `--ink`) y debajo la fecha larga
     ("jueves, 10 de julio", 12.5px `--faint`).
   - Derecha: campana en círculo 40px blanco con borde `--border`, punto acento 8px con borde blanco.
2. **Tablón de la comunidad** (componente nuevo `TablonBoard`, ver §3).
3. **Strip de parking** (sustituye la tarjeta grande): fila 1 línea, radio 16,
   degradado `var(--grad-hero)`, icono coche 26px, overline "PARKING EXTERIOR"
   (11/700 blanco 65%), texto "Esta quincena: **Plaza N**" (14.5px), chevron ›.
4. **Votación slim**: fila blanca borde `--border`, radio 16, punto info 8px, título 13.5/700,
   meta "Votación abierta · cierra en N días" (12px `--faint`), botón pill "Votar"
   (12/700 `--primary-700` sobre `--primary-soft`).
5. **Servicios en círculo** (sustituye los tiles de color): overline "SERVICIOS", rejilla
   `grid-cols-4`, gap 14px vertical / 8px horizontal. Cada ítem: círculo 54px, fondo blanco,
   borde `--border`, sombra `0 4px 10px -5px rgba(30,50,60,.35)`, icono lucide 22px stroke 1.9
   en el **color fijo del módulo** (mismos hex actuales del array `tiles`); etiqueta debajo
   11/600 `--muted`, centrada. Etiquetas cortas: Mensajes, Buzón, Votaciones, Reservas,
   Parking, Contactos, Reciclaje, Sugerencias.

Desaparecen: el carrusel horizontal "Actividad reciente" (lo absorbe el tablón) y la rejilla
de tiles de colores.

### 3. Componente nuevo: `src/features/mensajes/TablonBoard.tsx`
Tarjeta contenedora: blanco, radio 20, borde `--border`, sombra media.
- Cabecera: icono megáfono 18px `--primary-700` + "Tablón de la comunidad" (Bricolage 16/800)
  + enlace "Ver todo ›" (12/700 `--primary-700`) → navega a `/mensajes`.
- Superficie interior (margen 12, radio 14): fondo rayado
  `repeating-linear-gradient(45deg,#EDF2F4 0 6px,#E8EEF1 6px 12px)`, borde `#DDE5E9`,
  padding 16px 14px, columna con gap 16px.
- Dentro, una **PostItNote por tipo de mensaje** (aviso / anuncio / incidencia), con los
  mensajes agrupados (ver §6). Rotaciones alternas: −1deg, 0.8deg, −0.6deg.

### 4. Componente nuevo: `src/features/mensajes/PostItNote.tsx`
Nota de papel. Props: `mensaje`, `count` (nº del grupo), `onClick`.
- Papel: radio 4, padding 14px 14px 10px, sombra
  `0 6px 14px -6px rgba(30,50,60,.35), inset 0 1px 0 rgba(255,255,255,.8)`.
- Colores por tipo (papel / chincheta / tinta de etiqueta):
  - aviso: `#FFF7DF` / `#C33B2C` (brillo `#F08A7E`) / `#8A5A0F`
  - anuncio: `#FFFFFF` / `#2F5FA3` (brillo `#7FB4E8`) / `#177E8B` (usa `--primary-700`)
  - incidencia: `#FFF1EE` / `#1B9E5A` (brillo `#7FD3A2`) / `#A3341F`
- **Chincheta**: círculo 14px centrado arriba (top −7px),
  `radial-gradient(circle at 35% 30%, <brillo>, <color>)`, sombra `0 3px 4px rgba(0,0,0,.3)`.
- Cabecera de la nota: etiqueta tipo en mayúsculas (10.5/800, tracking .1em, color tinta;
  plural si count>1: "AVISOS") + **fecha manuscrita rodeada**: Caveat 17/600 color tinta,
  `transform: rotate(-2deg)`, padding 0 9px, borde 1.5px sólido color tinta,
  `border-radius: 55% 45% 50% 60% / 65% 55% 60% 50%`, opacity .85. Texto: "hoy", "ayer", "10 jul".
- Título: Bricolage 16/800 `--ink`; cuerpo 13px `--muted`, `line-clamp-2`.
- Pie: si count>1, "+N aviso(s) más · toca para ver" (11.5/700 `--primary-700`); si el aviso
  tiene expiración, **sello de caducidad** a la derecha: "CADUCA EN N DÍAS" 9.5/800 mayúsculas,
  color tinta, borde 1px **dashed** color tinta, radio 3, padding 2px 7px,
  `rotate(-1.5deg)`, opacity .75.
- **Efecto pila** (count>1): dos capas absolutas detrás del papel (mismo tamaño, color papel
  oscurecido ~8%), `rotate(2.4deg) translate(4px,2px)` y `rotate(-1.6deg) translate(-3px,3px)`,
  sombra suave. Badge contador: círculo ≥24px, top −9 right −7, fondo `--primary-700`,
  texto blanco 11.5/800, borde 2px blanco.

### 5. Componente nuevo: `src/features/mensajes/PostItPadModal.tsx`
Modal a pantalla completa (portal sobre la Home, dentro del viewport de la app):
- Fondo `rgba(19,37,32,.55)` + `backdrop-filter: blur(3px)`.
- Cabecera: título "Avisos (2)" (Bricolage 20/800 blanco), subtítulo
  "Levanta el post-it para ver el siguiente" (12.5px blanco 70%), botón ✕ circular 40px
  blanco 18%.
- **Bloc (deck)**: contenedor centrado, padding lateral 28px, `perspective: 1000px`;
  área de nota de altura fija ~340px, `position: relative`.
  - Se renderizan hasta 3 hojas (índice actual + 2): la superior interactiva; las de detrás
    con `scale(1 − pos*0.04) translateY(pos*12px) rotate(±1deg)`, **sin transición** (ya están
    colocadas debajo; la siguiente NO debe animarse al pasar a ser superior — este detalle es
    importante, ver §Interacciones).
  - Hoja: papel del tipo, radio 4, padding 26px 22px 16px, banda adhesiva superior
    (franja 16px `rgba(0,0,0,.05)` con borde inferior dashed), esquina doblada inferior-dcha
    (triángulo CSS 22px `rgba(0,0,0,.12)`), fecha manuscrita rodeada (Caveat 21px),
    título Bricolage 22/800, cuerpo 14.5/1.6, sello de caducidad si aplica,
    pie con "Hoja X de N" (11/700 `--faint`) y firma manuscrita "— la Junta" /
    "— Conserjería" (Caveat 19px color tinta, alineada dcha).
- Pie del modal: puntos de progreso (activo: 22×8px blanco; resto 8×8px blanco 35%).
- Estado final: al despegar la última hoja → "✓ Estás al día" (Bricolage 19/800 blanco) +
  botón blanco pill "Volver a empezar".

### 6. Datos: agrupar mensajes por tipo
En `HomePage` (o un hook `useTablon()`): partir de la misma lista filtrada de "actividad
reciente" que ya calcula la Home (incidencias abiertas, avisos vigentes, anuncios ≤2 días) y
`groupBy(tipo)`. Cada grupo pinta una PostItNote (mensaje más reciente arriba) con
`count = grupo.length`. Tipos sin mensajes no pintan nota. El modal recibe el array del grupo.
La fecha manuscrita: `hoy` / `ayer` / `fechaCorta()` abreviada ("10 jul"). La caducidad solo
para avisos con `expira_at` ("caduca en N días").

---

## Interactions & Behavior

### Pila → modal
- Tap en cualquier nota del tablón abre `PostItPadModal` con su grupo (también con 1 sola nota).
- Cerrar: botón ✕ o tap en el fondo oscuro.

### Despegar hoja (gesto)
Pointer events sobre la hoja superior (`setPointerCapture`, `touch-action: none`):
- **Drag**: solo hacia arriba (`dy = min(0, clientY − startY)`). Durante el drag, sin transición:
  `transform: perspective(900px) translateY(dy*0.45px) rotateX(min(52, −dy*0.16)deg)`,
  `transform-origin: 50% 0%` (la hoja se dobla desde el borde superior, como despegarla).
  La sombra crece con el levantamiento.
- **Soltar con −dy > 90px** → despegue: transición `transform .3s ease-in, opacity .3s ease-in`
  hacia `translateY(-460px) rotateX(58deg) rotate(-7deg)`, opacity 0; a los ~300ms se
  incrementa el índice.
- **Soltar antes del umbral** → snap-back con `transform .3s ease` (flag `snapping` ~320ms).
- **Tap sin arrastre** (−dy < 6px) → también despega (accesibilidad/rapidez).
- ⚠️ **Al promover la siguiente hoja a superior NO aplicar transición**: debe aparecer ya
  colocada debajo (si se anima, parece que "baja" — efecto indeseado ya corregido en el diseño).
- Respeta `prefers-reduced-motion` (global.css ya lo hace).

### Estado
- Modal: `{ tipoAbierto: MensajeTipo | null, idx: number, dragY: number, dragging, peeling, snapping }`.
- Sin persistencia; al reabrir empieza en la hoja 1.

---

## Design Tokens usados (resumen)
- Colores base: los de `tokens.css` (paleta turquesa por defecto: `--primary #2BB0C0`,
  `--primary-700 #177E8B`… ). Fondo Home `#F4F7F9`.
- Papeles post-it: `#FFF7DF` (aviso), `#FFFFFF` (anuncio), `#FFF1EE` (incidencia);
  capas de pila: `#F3E7BF`, `#E8ECEF`, `#F2DBD5`.
- Tintas de nota: `#8A5A0F`, `#177E8B`, `#A3341F`. Chinchetas: `#C33B2C`, `#2F5FA3`, `#1B9E5A`.
- Colores fijos de módulo (círculos de servicios): `#E0A22E, #3E7CB1, #5B7FD4, #2E8E79,
  #8A6FD1, #D98A3D, #6BAA4E, #C879A9` (mismos del `tiles` actual).
- Tipografías: Bricolage Grotesque (display), Figtree (UI), **Caveat** (manuscrita, nueva).
- Radios: nota 4px, tarjetas 16–20px, pills 999px. Rotaciones: ±0.6–2.4deg.
- Dark mode: derivar papeles con `color-mix` sobre `--surface` (p. ej.
  `color-mix(in srgb, #F6DD84 20%, var(--surface))`) y tintas → las variantes `-ink` oscuras.

## Assets
- Sin imágenes. Iconos: lucide-react ya instalado (Megaphone, Bell, Car, etc.).
- Fuente nueva: Caveat 600/700 (Google Fonts).
- Chinchetas, celo, banda adhesiva y esquina doblada: CSS puro (gradientes/bordes), sin SVG.

## Files
- `Home Propuestas.dc.html` — referencia visual. La opción a implementar es **2a**
  (primera sección). El popup/bloc está en el mismo archivo (se abre pulsando una pila).
